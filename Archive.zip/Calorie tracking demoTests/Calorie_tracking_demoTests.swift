//
//  Calorie_tracking_demoTests.swift
//  Calorie tracking demoTests
//
//  Created by DEV7E on 26/04/2026.
//

import Testing

struct Calorie_tracking_demoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
