//
//  Double+Format.swift
//  Calorie tracking demo
//

import Foundation

extension Double {
    func formattedDecimal(maxFractionDigits: Int = 8) -> String {
        if truncatingRemainder(dividingBy: 1) == 0 && abs(self) < 1e9 {
            return String(Int(self))
        }
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = maxFractionDigits
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: self)) ?? String(self)
    }

    func formattedCurrency(code: String = "USD") -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = code
        return formatter.string(from: NSNumber(value: self)) ?? String(self)
    }

    func formattedPercent() -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 2
        formatter.positivePrefix = "+"
        let str = formatter.string(from: NSNumber(value: self)) ?? String(self)
        return "\(str)%"
    }
}
