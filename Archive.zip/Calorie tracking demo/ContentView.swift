//
//  ContentView.swift
//  Calorie tracking demo
//

import SwiftUI

struct ContentView: View {
    @State private var selection: AppTab = .calculator

    var body: some View {
        TabView(selection: $selection) {
            CalculatorView()
                .tabItem { Label(AppTab.calculator.title, systemImage: AppTab.calculator.systemImage) }
                .tag(AppTab.calculator)

            WeatherView()
                .tabItem { Label(AppTab.weather.title, systemImage: AppTab.weather.systemImage) }
                .tag(AppTab.weather)

            NotesListView()
                .tabItem { Label(AppTab.notes.title, systemImage: AppTab.notes.systemImage) }
                .tag(AppTab.notes)

            StocksView()
                .tabItem { Label(AppTab.stocks.title, systemImage: AppTab.stocks.systemImage) }
                .tag(AppTab.stocks)
        }
    }
}

#Preview {
    ContentView()
}
