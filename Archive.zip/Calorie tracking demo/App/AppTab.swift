//
//  AppTab.swift
//  Calorie tracking demo
//

import Foundation

enum AppTab: Int, CaseIterable, Identifiable {
    case calculator
    case weather
    case notes
    case stocks

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .calculator: return "الحاسبة"
        case .weather:    return "الطقس"
        case .notes:      return "الملاحظات"
        case .stocks:     return "الأسهم"
        }
    }

    var systemImage: String {
        switch self {
        case .calculator: return "plusminus.circle"
        case .weather:    return "thermometer.sun"
        case .notes:      return "note.text"
        case .stocks:     return "chart.line.uptrend.xyaxis"
        }
    }
}
