//
//  Calorie_tracking_demoApp.swift
//  Calorie tracking demo
//
//  Created by DEV7E on 26/04/2026.
//

import SwiftUI

@main
struct Calorie_tracking_demoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
