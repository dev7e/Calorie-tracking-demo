//
//  CalculatorButtonView.swift
//  Calorie tracking demo
//

import SwiftUI

struct CalculatorButtonView: View {
    let button: CalculatorButton
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(button.title)
                .font(.system(size: 32, weight: .medium))
                .foregroundColor(button.textColor)
                .frame(width: button.isWide ? 168 : 78, height: 78)
                .background(button.color)
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}
