//
//  CalculatorView.swift
//  Calorie tracking demo
//

import SwiftUI

struct CalculatorView: View {
    @StateObject private var viewModel = CalculatorViewModel()

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 12) {
                Spacer()

                HStack {
                    Spacer()
                    Text(viewModel.display)
                        .font(.system(size: 80, weight: .light))
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.4)
                        .padding(.horizontal, 24)
                }

                ForEach(CalculatorLayout.rows.indices, id: \.self) { rowIndex in
                    HStack(spacing: 12) {
                        ForEach(CalculatorLayout.rows[rowIndex]) { button in
                            CalculatorButtonView(button: button) {
                                viewModel.handleTap(button.title)
                            }
                        }
                    }
                }
            }
            .padding(.bottom, 24)
        }
    }
}

#Preview {
    CalculatorView()
}
