//
//  CalculatorViewModel.swift
//  Calorie tracking demo
//

import Foundation

@MainActor
final class CalculatorViewModel: ObservableObject {
    @Published private(set) var display: String = "0"

    private var accumulator: Double = 0
    private var pendingOperation: CalculatorOperation = .none
    private var isTypingNumber: Bool = false
    private let maxDigits: Int = 9

    func handleTap(_ title: String) {
        switch title {
        case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9":
            appendDigit(title)
        case ".":
            appendDecimal()
        case "AC":
            clear()
        case "+/-":
            toggleSign()
        case "%":
            applyPercent()
        case "+":
            setOperation(.add)
        case "−":
            setOperation(.subtract)
        case "×":
            setOperation(.multiply)
        case "÷":
            setOperation(.divide)
        case "=":
            evaluate()
        default:
            break
        }
    }

    private func appendDigit(_ digit: String) {
        if isTypingNumber {
            guard display.count < maxDigits else { return }
            display += digit
        } else {
            display = digit
            isTypingNumber = true
        }
    }

    private func appendDecimal() {
        if !isTypingNumber {
            display = "0."
            isTypingNumber = true
        } else if !display.contains(".") {
            display += "."
        }
    }

    private func clear() {
        display = "0"
        accumulator = 0
        pendingOperation = .none
        isTypingNumber = false
    }

    private func toggleSign() {
        guard let value = Double(display) else { return }
        display = (-value).formattedDecimal()
    }

    private func applyPercent() {
        guard let value = Double(display) else { return }
        display = (value / 100).formattedDecimal()
    }

    private func setOperation(_ op: CalculatorOperation) {
        if isTypingNumber {
            evaluate()
        }
        pendingOperation = op
        isTypingNumber = false
    }

    private func evaluate() {
        guard let displayValue = Double(display) else { return }
        let result = pendingOperation.apply(accumulator, displayValue)
        accumulator = result
        display = result.formattedDecimal()
        pendingOperation = .none
        isTypingNumber = false
    }
}
