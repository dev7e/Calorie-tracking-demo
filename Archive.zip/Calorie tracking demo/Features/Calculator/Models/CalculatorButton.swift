//
//  CalculatorButton.swift
//  Calorie tracking demo
//

import SwiftUI

struct CalculatorButton: Identifiable {
    let id = UUID()
    let title: String
    let color: Color
    let textColor: Color
    let isWide: Bool

    init(title: String,
         color: Color,
         textColor: Color = .white,
         isWide: Bool = false) {
        self.title = title
        self.color = color
        self.textColor = textColor
        self.isWide = isWide
    }
}

enum CalculatorLayout {
    static let rows: [[CalculatorButton]] = [
        [
            .init(title: "AC", color: Color(.lightGray), textColor: .black),
            .init(title: "+/-", color: Color(.lightGray), textColor: .black),
            .init(title: "%", color: Color(.lightGray), textColor: .black),
            .init(title: "÷", color: .orange)
        ],
        [
            .init(title: "7", color: Color(.darkGray)),
            .init(title: "8", color: Color(.darkGray)),
            .init(title: "9", color: Color(.darkGray)),
            .init(title: "×", color: .orange)
        ],
        [
            .init(title: "4", color: Color(.darkGray)),
            .init(title: "5", color: Color(.darkGray)),
            .init(title: "6", color: Color(.darkGray)),
            .init(title: "−", color: .orange)
        ],
        [
            .init(title: "1", color: Color(.darkGray)),
            .init(title: "2", color: Color(.darkGray)),
            .init(title: "3", color: Color(.darkGray)),
            .init(title: "+", color: .orange)
        ],
        [
            .init(title: "0", color: Color(.darkGray), isWide: true),
            .init(title: ".", color: Color(.darkGray)),
            .init(title: "=", color: .orange)
        ]
    ]
}
