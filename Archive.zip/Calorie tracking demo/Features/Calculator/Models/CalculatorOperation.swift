//
//  CalculatorOperation.swift
//  Calorie tracking demo
//

import Foundation

enum CalculatorOperation {
    case add
    case subtract
    case multiply
    case divide
    case none

    func apply(_ lhs: Double, _ rhs: Double) -> Double {
        switch self {
        case .add:      return lhs + rhs
        case .subtract: return lhs - rhs
        case .multiply: return lhs * rhs
        case .divide:   return rhs == 0 ? 0 : lhs / rhs
        case .none:     return rhs
        }
    }
}
