//
//  Stock.swift
//  Calorie tracking demo
//

import Foundation

struct Stock: Identifiable, Equatable {
    let id: String
    let symbol: String
    let name: String
    let price: Double
    let changePercent: Double

    var isUp: Bool { changePercent >= 0 }
}
