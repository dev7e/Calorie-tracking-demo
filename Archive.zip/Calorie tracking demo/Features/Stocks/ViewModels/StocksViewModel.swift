//
//  StocksViewModel.swift
//  Calorie tracking demo
//

import Foundation

@MainActor
final class StocksViewModel: ObservableObject {
    @Published private(set) var stocks: [Stock] = []
    @Published private(set) var isLoading: Bool = false
    @Published private(set) var lastUpdated: Date?

    private let service: StocksProviding

    init(service: StocksProviding = StocksService()) {
        self.service = service
    }

    func loadIfNeeded() async {
        guard stocks.isEmpty else { return }
        await refresh()
    }

    func refresh() async {
        isLoading = true
        let result = await service.fetchTodayStocks()
        stocks = result
        lastUpdated = Date()
        isLoading = false
    }

    var marketSummary: String {
        guard !stocks.isEmpty else { return "—" }
        let gainers = stocks.filter { $0.isUp }.count
        let losers = stocks.count - gainers
        return "\(gainers) صاعد · \(losers) هابط"
    }
}
