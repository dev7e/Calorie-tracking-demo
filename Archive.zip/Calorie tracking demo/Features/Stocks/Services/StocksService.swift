//
//  StocksService.swift
//  Calorie tracking demo
//

import Foundation

protocol StocksProviding {
    func fetchTodayStocks() async -> [Stock]
}

final class StocksService: StocksProviding {
    private let seedSymbols: [(String, String, Double)] = [
        ("2222.SR", "أرامكو السعودية",   28.50),
        ("1120.SR", "الراجحي",           96.20),
        ("7010.SR", "STC",               40.10),
        ("1180.SR", "الأهلي",            34.75),
        ("2010.SR", "سابك",              74.90),
        ("4030.SR", "البحري",            32.40),
        ("1211.SR", "معادن",             54.30),
        ("4001.SR", "أسواق المزرعة",     58.10)
    ]

    func fetchTodayStocks() async -> [Stock] {
        try? await Task.sleep(nanoseconds: 350_000_000)
        return seedSymbols.map { symbol, name, base in
            let change = Double.random(in: -3.5...3.5)
            let priceFactor = 1 + (change / 100)
            return Stock(
                id: symbol,
                symbol: symbol,
                name: name,
                price: (base * priceFactor * 100).rounded() / 100,
                changePercent: (change * 100).rounded() / 100
            )
        }
    }
}
