//
//  StocksView.swift
//  Calorie tracking demo
//

import SwiftUI

struct StocksView: View {
    @StateObject private var viewModel = StocksViewModel()

    var body: some View {
        NavigationStack {
            Group {
                if viewModel.isLoading && viewModel.stocks.isEmpty {
                    ProgressView("جاري تحميل بيانات السوق...")
                } else {
                    List {
                        Section {
                            HStack {
                                Text("ملخص السوق").font(.subheadline.bold())
                                Spacer()
                                Text(viewModel.marketSummary)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            if let updated = viewModel.lastUpdated {
                                Text("آخر تحديث: \(updated.formatted(date: .omitted, time: .shortened))")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }

                        Section("الأسهم") {
                            ForEach(viewModel.stocks) { stock in
                                StockRowView(stock: stock)
                            }
                        }
                    }
                    .refreshable { await viewModel.refresh() }
                }
            }
            .navigationTitle("صندوق الأسهم اليوم")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task { await viewModel.refresh() }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                    .disabled(viewModel.isLoading)
                }
            }
            .task { await viewModel.loadIfNeeded() }
        }
    }
}

#Preview {
    StocksView()
}
