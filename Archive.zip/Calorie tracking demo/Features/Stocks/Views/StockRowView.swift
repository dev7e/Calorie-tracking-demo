//
//  StockRowView.swift
//  Calorie tracking demo
//

import SwiftUI

struct StockRowView: View {
    let stock: Stock

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(stock.symbol)
                    .font(.headline)
                Text(stock.name)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 4) {
                Text(stock.price.formattedDecimal(maxFractionDigits: 2))
                    .font(.headline)
                    .monospacedDigit()
                HStack(spacing: 4) {
                    Image(systemName: stock.isUp ? "arrow.up.right" : "arrow.down.right")
                    Text(stock.changePercent.formattedPercent())
                        .monospacedDigit()
                }
                .font(.caption.bold())
                .foregroundColor(.white)
                .padding(.vertical, 3)
                .padding(.horizontal, 8)
                .background(stock.isUp ? Color.green : Color.red)
                .clipShape(Capsule())
            }
        }
        .padding(.vertical, 4)
    }
}
