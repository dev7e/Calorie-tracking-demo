//
//  WeatherViewModel.swift
//  Calorie tracking demo
//

import Foundation

@MainActor
final class WeatherViewModel: ObservableObject {
    @Published private(set) var info: WeatherInfo
    @Published var useFahrenheit: Bool = false

    private let cities: [String] = ["الرياض", "جدة", "الدمام", "مكة", "أبها"]

    init() {
        self.info = WeatherViewModel.makeRandomReading(city: "الرياض")
    }

    var temperatureText: String {
        let value = useFahrenheit ? info.temperatureFahrenheit : info.temperatureCelsius
        let unit = useFahrenheit ? "°F" : "°C"
        return "\(Int(value.rounded()))\(unit)"
    }

    func refresh() {
        info = WeatherViewModel.makeRandomReading(city: info.city)
    }

    func cycleCity() {
        let next = cities.randomElement() ?? info.city
        info = WeatherViewModel.makeRandomReading(city: next)
    }

    private static func makeRandomReading(city: String) -> WeatherInfo {
        let condition = WeatherCondition.allCases.randomElement() ?? .sunny
        let baseTemp: ClosedRange<Double>
        switch condition {
        case .sunny:        baseTemp = 30...44
        case .partlyCloudy: baseTemp = 24...34
        case .cloudy:       baseTemp = 18...28
        case .rainy:        baseTemp = 12...22
        case .stormy:       baseTemp = 10...20
        }
        return WeatherInfo(
            city: city,
            temperatureCelsius: Double.random(in: baseTemp),
            condition: condition,
            humidity: Int.random(in: 10...90),
            windSpeedKph: Double.random(in: 2...35),
            updatedAt: Date()
        )
    }
}
