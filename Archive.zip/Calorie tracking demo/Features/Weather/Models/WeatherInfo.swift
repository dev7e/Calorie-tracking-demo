//
//  WeatherInfo.swift
//  Calorie tracking demo
//

import Foundation

struct WeatherInfo: Equatable {
    let city: String
    let temperatureCelsius: Double
    let condition: WeatherCondition
    let humidity: Int
    let windSpeedKph: Double
    let updatedAt: Date

    var temperatureFahrenheit: Double {
        temperatureCelsius * 9 / 5 + 32
    }
}

enum WeatherCondition: String, CaseIterable {
    case sunny
    case partlyCloudy
    case cloudy
    case rainy
    case stormy

    var label: String {
        switch self {
        case .sunny:        return "مشمس"
        case .partlyCloudy: return "غائم جزئياً"
        case .cloudy:       return "غائم"
        case .rainy:        return "ممطر"
        case .stormy:       return "عاصف"
        }
    }

    var systemImage: String {
        switch self {
        case .sunny:        return "sun.max.fill"
        case .partlyCloudy: return "cloud.sun.fill"
        case .cloudy:       return "cloud.fill"
        case .rainy:        return "cloud.rain.fill"
        case .stormy:       return "cloud.bolt.rain.fill"
        }
    }
}
