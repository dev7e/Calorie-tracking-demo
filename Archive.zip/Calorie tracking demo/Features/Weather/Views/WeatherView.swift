//
//  WeatherView.swift
//  Calorie tracking demo
//

import SwiftUI

struct WeatherView: View {
    @StateObject private var viewModel = WeatherViewModel()

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [Color.blue.opacity(0.8), Color.cyan.opacity(0.5)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    Text(viewModel.info.city)
                        .font(.largeTitle.bold())
                        .foregroundColor(.white)

                    Image(systemName: viewModel.info.condition.systemImage)
                        .font(.system(size: 110))
                        .foregroundColor(.white)
                        .symbolRenderingMode(.multicolor)

                    Text(viewModel.temperatureText)
                        .font(.system(size: 86, weight: .thin))
                        .foregroundColor(.white)

                    Text(viewModel.info.condition.label)
                        .font(.title2)
                        .foregroundColor(.white.opacity(0.9))

                    HStack(spacing: 30) {
                        WeatherStatView(
                            icon: "humidity.fill",
                            label: "الرطوبة",
                            value: "\(viewModel.info.humidity)%"
                        )
                        WeatherStatView(
                            icon: "wind",
                            label: "الرياح",
                            value: "\(Int(viewModel.info.windSpeedKph)) كم/س"
                        )
                    }
                    .padding(.top, 10)

                    Toggle("عرض بالفهرنهايت", isOn: $viewModel.useFahrenheit)
                        .padding(.horizontal, 40)
                        .foregroundColor(.white)
                        .tint(.white.opacity(0.6))

                    Spacer()
                }
                .padding(.top, 40)
            }
            .navigationTitle("درجة الحرارة اليوم")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: viewModel.refresh) {
                        Image(systemName: "arrow.clockwise")
                    }
                }
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: viewModel.cycleCity) {
                        Image(systemName: "location.circle")
                    }
                }
            }
        }
    }
}

private struct WeatherStatView: View {
    let icon: String
    let label: String
    let value: String

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.title2)
            Text(value).font(.headline)
            Text(label).font(.caption)
        }
        .foregroundColor(.white)
        .frame(width: 110, height: 90)
        .background(Color.white.opacity(0.15))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }
}

#Preview {
    WeatherView()
}
