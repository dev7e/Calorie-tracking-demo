//
//  NotesStorage.swift
//  Calorie tracking demo
//

import Foundation

protocol NotesStoring {
    func load() -> [Note]
    func save(_ notes: [Note])
}

final class NotesStorage: NotesStoring {
    private let key = "notes.storage.v1"
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }

    func load() -> [Note] {
        guard let data = defaults.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([Note].self, from: data)) ?? []
    }

    func save(_ notes: [Note]) {
        guard let data = try? JSONEncoder().encode(notes) else { return }
        defaults.set(data, forKey: key)
    }
}
