//
//  NotesListView.swift
//  Calorie tracking demo
//

import SwiftUI

struct NotesListView: View {
    @StateObject private var viewModel = NotesViewModel()
    @State private var isPresentingCreate = false
    @State private var editingNote: Note?

    var body: some View {
        NavigationStack {
            Group {
                if viewModel.notes.isEmpty {
                    ContentUnavailableView(
                        "لا توجد ملاحظات",
                        systemImage: "note.text",
                        description: Text("اضغط على + لإضافة ملاحظة جديدة")
                    )
                } else {
                    List {
                        ForEach(viewModel.notes) { note in
                            Button { editingNote = note } label: {
                                NoteRowView(note: note)
                            }
                            .buttonStyle(.plain)
                        }
                        .onDelete(perform: viewModel.delete)
                    }
                }
            }
            .navigationTitle("الملاحظات")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { isPresentingCreate = true } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $isPresentingCreate) {
                NoteEditorView(mode: .create) { title, body in
                    viewModel.add(title: title, body: body)
                }
            }
            .sheet(item: $editingNote) { note in
                NoteEditorView(mode: .edit(note)) { title, body in
                    viewModel.update(note, title: title, body: body)
                }
            }
        }
    }
}

#Preview {
    NotesListView()
}
