//
//  NoteEditorView.swift
//  Calorie tracking demo
//

import SwiftUI

struct NoteEditorView: View {
    enum Mode {
        case create
        case edit(Note)
    }

    let mode: Mode
    let onSave: (_ title: String, _ body: String) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var title: String
    @State private var body: String

    init(mode: Mode, onSave: @escaping (String, String) -> Void) {
        self.mode = mode
        self.onSave = onSave
        switch mode {
        case .create:
            _title = State(initialValue: "")
            _body = State(initialValue: "")
        case .edit(let note):
            _title = State(initialValue: note.title)
            _body = State(initialValue: note.body)
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("العنوان") {
                    TextField("عنوان الملاحظة", text: $title)
                }
                Section("المحتوى") {
                    TextEditor(text: $body)
                        .frame(minHeight: 200)
                }
            }
            .navigationTitle(navigationTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("حفظ") {
                        onSave(title, body)
                        dismiss()
                    }
                    .disabled(title.trimmingCharacters(in: .whitespaces).isEmpty &&
                              body.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }

    private var navigationTitle: String {
        switch mode {
        case .create: return "ملاحظة جديدة"
        case .edit:   return "تعديل ملاحظة"
        }
    }
}
