//
//  NotesViewModel.swift
//  Calorie tracking demo
//

import Foundation

@MainActor
final class NotesViewModel: ObservableObject {
    @Published private(set) var notes: [Note] = []

    private let storage: NotesStoring

    init(storage: NotesStoring = NotesStorage()) {
        self.storage = storage
        self.notes = storage.load().sorted { $0.updatedAt > $1.updatedAt }
    }

    func add(title: String, body: String) {
        let trimmedTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedBody = body.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedTitle.isEmpty || !trimmedBody.isEmpty else { return }
        let finalTitle = trimmedTitle.isEmpty ? String(trimmedBody.prefix(30)) : trimmedTitle
        let note = Note(title: finalTitle, body: trimmedBody)
        notes.insert(note, at: 0)
        persist()
    }

    func update(_ note: Note, title: String, body: String) {
        guard let index = notes.firstIndex(where: { $0.id == note.id }) else { return }
        notes[index].title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        notes[index].body = body.trimmingCharacters(in: .whitespacesAndNewlines)
        notes[index].updatedAt = Date()
        notes.sort { $0.updatedAt > $1.updatedAt }
        persist()
    }

    func delete(at offsets: IndexSet) {
        notes.remove(atOffsets: offsets)
        persist()
    }

    private func persist() {
        storage.save(notes)
    }
}
